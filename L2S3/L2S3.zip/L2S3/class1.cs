﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2S3
{
    internal class Bektor
    {
        public Bektor() { }
        public Bektor summ()//+
        {
            return new Bektor();
        }
        public Bektor compare()
        {
            return new Bektor();
        }
        public Bektor copy()
        {
            return new Bektor
            {
                // присваивание полей a = this.a
            };
        }
        public bool Check(Bektor obj)
        {
            if (obj == null || (/* проверка 2 */)) return true;
            else return false;
        }
        public void Cut(Bektor obj) {
        }
        public void CutPositive(Bektor obj) {
        }

    }
    /*Класс - Вектор. Дополнительно перегрузить следующие операции: + -
сложение векторов; > - сравнение векторов; == - копирование вектора, true
- проверка, пустой ли вектор
Методы расширения:
1) Усечение строки с начала
2) Удаление положительных элементов из вектора*/
}
