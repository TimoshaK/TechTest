﻿using System;
using System.Text;
using static System.Console;
namespace L2S3
{
    public class Programm
    {
        static ConsoleColor color = ConsoleColor.Black;
        static ConsoleColor fcolor = ConsoleColor.DarkMagenta;
        static int xmin = 34;
        public static int x;
        public static int X_end_of_Inteface = 5;
        static void Main()
        {
            Title = "<Test programm>";
            OutputEncoding = Encoding.Unicode;
            SetBufferSize(500, 500);
            x = 50;
            SetWindowSize(x, 30);

        }
    }
}
